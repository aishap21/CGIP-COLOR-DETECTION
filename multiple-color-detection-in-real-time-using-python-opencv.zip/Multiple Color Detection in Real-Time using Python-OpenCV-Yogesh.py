import cv2
import numpy as np

cap = cv2.VideoCapture(0)

HSV_value_color = [

    ((0, 100, 100), (10, 255, 255), 'Red'),
    ((36, 100, 100), (70, 255, 255), 'Green'),
    ((110, 100, 100), (130, 255, 255), 'Blue')
]

while True:
    ret, frame = cap.read()

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    for (lower, upper, color_name) in HSV_value_color:
        mask = cv2.inRange(hsv, np.array(lower), np.array(upper))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 500:
                x, y, w, h = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (167, 49, 195), 2)
                cv2.putText(frame, color_name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (195, 86, 114), 2)
        cv2.imshow('mask', mask)
    cv2.imshow('ProjectGurukul', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
